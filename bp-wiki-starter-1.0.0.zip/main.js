const { Notice, Plugin, PluginSettingTab, Setting, normalizePath } = require("obsidian");

const STARTER_ROOT = "BP-Wiki Starter";

const TEMPLATES = [
  {
    id: "01-PARA",
    name: "PARA",
    zh: "按行动相关性组织项目、责任、资源和归档。",
    en: "Organize projects, areas, resources, and archives by action relevance.",
    folders: ["00-Inbox", "01-Projects", "02-Areas", "03-Resources", "04-Archives", "Daily"],
    bestForZh: "职场项目、内容项目、阶段性研究。",
    bestForEn: "Work projects, content projects, and staged research."
  },
  {
    id: "02-Zettelkasten",
    name: "Zettelkasten",
    zh: "用原子笔记、唯一 ID 和双向链接构建长期思想网络。",
    en: "Build a long-term idea network with atomic notes, unique IDs, and links.",
    folders: ["00-Fleeting", "01-Literature", "02-Permanent", "99-Index"],
    bestForZh: "长期写作、研究和理论积累。",
    bestForEn: "Long-term writing, research, and theory building."
  },
  {
    id: "03-GTD",
    name: "GTD",
    zh: "把任务全部外化，再按下一步行动、等待和将来也许分流。",
    en: "Externalize tasks, then route them by next action, waiting, and someday.",
    folders: ["00-Inbox", "01-Next-Actions", "02-Projects", "03-Waiting", "04-Someday", "05-Review"],
    bestForZh: "任务多、协作多、日程密集的人。",
    bestForEn: "People with many tasks, collaborators, and schedules."
  },
  {
    id: "04-Digital-Garden",
    name: "Digital Garden",
    zh: "按成熟度管理想法，让笔记从种子长成常青内容。",
    en: "Manage ideas by maturity, from seeds to evergreen notes.",
    folders: ["00-Seeds", "01-Growing", "02-Evergreen", "03-Published"],
    bestForZh: "公开写作、博客和创作型知识管理。",
    bestForEn: "Public writing, blogging, and creative knowledge work."
  },
  {
    id: "05-LYT-MOC",
    name: "LYT + MOC",
    zh: "用内容地图替代深层文件夹，让主题关系浮出水面。",
    en: "Use maps of content instead of deep folders to reveal topic relationships.",
    folders: ["00-MOC", "01-Notes", "02-Sources", "03-Outputs"],
    bestForZh: "主题研究、知识整合和跨主题引用。",
    bestForEn: "Topic research, synthesis, and cross-topic reference."
  },
  {
    id: "06-Evergreen-Notes",
    name: "Evergreen Notes",
    zh: "标题即论点，笔记可讨论、可引用、可迭代。",
    en: "Use claim-like titles so notes can be discussed, cited, and improved.",
    folders: ["00-Inbox", "01-Fleeting", "02-Literature", "03-Evergreen", "04-Structure"],
    bestForZh: "深度思考、学术写作和长期论点沉淀。",
    bestForEn: "Deep thinking, academic writing, and long-term arguments."
  },
  {
    id: "07-Inbox-Tags",
    name: "Inbox + Tags",
    zh: "少文件夹，多标签，用清空纪律承接碎片输入。",
    en: "Use fewer folders and more tags, backed by disciplined inbox clearing.",
    folders: ["00-Inbox", "01-Areas", "02-Projects", "03-Archives"],
    bestForZh: "碎片来源多、暂时不想搭复杂系统的人。",
    bestForEn: "People with many fragments who want a lightweight system."
  },
  {
    id: "08-Daily-MOC",
    name: "Daily + MOC",
    zh: "用日记做时间入口，用 MOC 做主题入口。",
    en: "Use daily notes as time entry points and MOCs as topic entry points.",
    folders: ["00-Daily", "01-MOC", "02-Notes", "03-Reviews"],
    bestForZh: "习惯追踪、复盘和日记输入重的人。",
    bestForEn: "Habit tracking, reviews, and daily-note-heavy workflows."
  },
  {
    id: "09-INKAPA",
    name: "INKAPA",
    zh: "在 PARA 基础上增加 Ideas 和 Notes，更适合中文 PKM 进阶。",
    en: "Extend PARA with Ideas and Notes for Chinese PKM workflows.",
    folders: ["00-Ideas", "01-Notes", "02-Knowledge", "03-Projects", "04-Areas", "05-Archives"],
    bestForZh: "中文用户、PARA 进阶者、碎片灵感很多的人。",
    bestForEn: "Chinese PKM users, PARA power users, and idea-heavy workflows."
  },
  {
    id: "10-Cornell-Notes",
    name: "Cornell Notes",
    zh: "用主栏、线索栏和总结栏把阅读或课程转成知识。",
    en: "Use notes, cues, and summary sections to turn study into knowledge.",
    folders: ["00-Inbox", "01-Courses", "02-Reading", "03-Reviews", "04-Summaries"],
    bestForZh: "课程学习、读书笔记和考试复习。",
    bestForEn: "Courses, reading notes, and exam review."
  },
  {
    id: "11-MOC-Navigation",
    name: "MOC Navigation",
    zh: "文件保持扁平，通过主题地图和索引组织关系。",
    en: "Keep notes flat and organize relationships through maps and indexes.",
    folders: ["00-MOC", "01-Notes", "02-Indexes", "03-Assets"],
    bestForZh: "主题复杂、链接关系强的知识体系。",
    bestForEn: "Complex topics with strong linking needs."
  },
  {
    id: "12-Progressive-Formalization",
    name: "Progressive Formalization",
    zh: "让闪念、文献笔记和永久笔记逐步升级。",
    en: "Move from fleeting notes to literature notes to permanent notes.",
    folders: ["00-Fleeting", "01-Literature", "02-Permanent", "03-Used-In-Outputs"],
    bestForZh: "长期研究、深度阅读和持续写作。",
    bestForEn: "Long-term research, deep reading, and ongoing writing."
  }
];

const DEFAULT_SETTINGS = {
  language: "bilingual"
};

module.exports = class BPWikiStarterPlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());

    this.addCommand({
      id: "install-starter-kit",
      name: "Install starter kit",
      callback: () => this.installStarterKit()
    });

    this.addCommand({
      id: "open-edition-comparison",
      name: "Open edition comparison",
      callback: () => this.openOrCreateFile(`${STARTER_ROOT}/BP-Wiki Editions.md`, editionComparisonContent())
    });

    this.addCommand({
      id: "open-template-selector",
      name: "Open template selector",
      callback: () => this.openOrCreateFile(`${STARTER_ROOT}/Template Selector.md`, templateSelectorContent())
    });

    this.addSettingTab(new BPWikiStarterSettingTab(this.app, this));
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  async installStarterKit() {
    await this.ensureFolder(STARTER_ROOT);
    await this.createFileIfMissing(`${STARTER_ROOT}/README.md`, starterReadmeContent());
    await this.createFileIfMissing(`${STARTER_ROOT}/BP-Wiki Editions.md`, editionComparisonContent());
    await this.createFileIfMissing(`${STARTER_ROOT}/Template Selector.md`, templateSelectorContent());

    for (const template of TEMPLATES) {
      const templateRoot = `${STARTER_ROOT}/${template.id}`;
      await this.ensureFolder(templateRoot);
      await this.createFileIfMissing(`${templateRoot}/README.md`, templateReadmeContent(template));

      for (const folder of template.folders) {
        await this.ensureFolder(`${templateRoot}/${folder}`);
      }
    }

    new Notice("BP-Wiki Starter kit installed.");
    await this.openOrCreateFile(`${STARTER_ROOT}/README.md`, starterReadmeContent());
  }

  async openOrCreateFile(path, content) {
    await this.createFileIfMissing(path, content);

    const normalizedPath = normalizePath(path);
    const file = this.app.vault.getAbstractFileByPath(normalizedPath);
    if (file) {
      await this.app.workspace.getLeaf(false).openFile(file);
    }
  }

  async createFileIfMissing(path, content) {
    const normalizedPath = normalizePath(path);
    const existing = this.app.vault.getAbstractFileByPath(normalizedPath);

    if (!existing) {
      await this.ensureParentFolder(normalizedPath);
      await this.app.vault.create(normalizedPath, content);
    }
  }

  async ensureParentFolder(path) {
    const parts = path.split("/");
    parts.pop();
    if (parts.length > 0) {
      await this.ensureFolder(parts.join("/"));
    }
  }

  async ensureFolder(path) {
    const normalizedPath = normalizePath(path);
    if (!normalizedPath) return;

    const parts = normalizedPath.split("/");
    let current = "";

    for (const part of parts) {
      current = current ? `${current}/${part}` : part;
      const existing = this.app.vault.getAbstractFileByPath(current);
      if (!existing) {
        await this.app.vault.createFolder(current);
      }
    }
  }
};

class BPWikiStarterSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("h2", { text: "BP-Wiki Starter" });

    new Setting(containerEl)
      .setName("Install starter kit")
      .setDesc("Create 12 bilingual template structures under BP-Wiki Starter/.")
      .addButton((button) => {
        button
          .setButtonText("Install")
          .setCta()
          .onClick(() => this.plugin.installStarterKit());
      });

    new Setting(containerEl)
      .setName("Open edition comparison")
      .setDesc("Compare Free Starter, Pro Runtime, and Custom Implementation.")
      .addButton((button) => {
        button
          .setButtonText("Open")
          .onClick(() => this.plugin.openOrCreateFile(`${STARTER_ROOT}/BP-Wiki Editions.md`, editionComparisonContent()));
      });

    const editions = containerEl.createDiv({ cls: "bp-wiki-starter-editions" });
    editions.createEl("h3", { text: "Editions" });
    editions.createEl("p", { text: "Free Starter: 12 bilingual templates and setup guides." });
    editions.createEl("p", { text: "Pro Runtime: Dual-engine Runtime, project workbench, dashboard queues, inbox governance, and business templates." });
    editions.createEl("p", { text: "Custom Implementation: Private diagnosis, migration, tailoring, training, and support." });
  }
}

function starterReadmeContent() {
  return `# BP-Wiki Starter

BP-Wiki Starter helps you choose and install a knowledge-base structure before you commit to a heavier system.

BP-Wiki Starter 帮你在投入复杂系统前，先选择并安装一套适合自己的知识库结构。

## Start Here

1. Open [[Template Selector]].
2. Choose one structure based on your current friction.
3. Use the generated folder as a starter, then delete what you do not need.
4. Read [[BP-Wiki Editions]] if you need the Pro Runtime or a custom implementation.

## Core Idea

Do not ask "which folder is perfect?" Ask "what workflow should this vault support?"

不要先问“完美目录是什么”。先问“这个知识库要服务哪种工作流？”
`;
}

function editionComparisonContent() {
  return `# BP-Wiki Editions

| Edition | For | Includes | Payment |
| --- | --- | --- | --- |
| Free Starter | New Obsidian users and knowledge-base builders | 12 bilingual templates, setup guide, edition comparison, sample structure | Free |
| Pro Runtime | Business analysts, researchers, BP and decision-support workers | Dual-engine Runtime, project workbench, dashboard queues, inbox governance, business templates, content-pack updates | Optional paid subscription |
| Custom Implementation | Teams, consultants, and advanced knowledge workers | Private diagnosis, migration, Runtime tailoring, template customization, training and support | Project-based service |

## Free Starter

Free Starter gives you a clean structure and a practical starting point.

免费版提供干净的结构和可直接使用的起点。

## Pro Runtime

Pro Runtime turns a starter vault into a working business analysis system.

Pro 版把基础知识库升级为可运行的商业分析工作台。

## Custom Implementation

Custom Implementation is for teams or advanced users who need migration, tailoring, and training.

私人订制适合需要迁移、裁剪和培训的团队或重度用户。
`;
}

function templateSelectorContent() {
  const rows = TEMPLATES.map((template) => `| ${template.name} | ${template.zh} | ${template.en} | ${template.bestForZh} |`).join("\n");

  return `# Template Selector

| Template | 中文定位 | English Positioning | 适合场景 |
| --- | --- | --- | --- |
${rows}

## Selection Rule

- Task overload: GTD.
- Many projects and responsibilities: PARA or INKAPA.
- Complex topics and links: LYT + MOC or MOC Navigation.
- Long-term writing and research: Zettelkasten, Evergreen Notes, or Progressive Formalization.
- Heavy daily capture: Inbox + Tags or Daily + MOC.

## 选择规则

- 任务失控：GTD。
- 项目和责任很多：PARA 或 INKAPA。
- 主题复杂、链接关系强：LYT + MOC 或 MOC Navigation。
- 长期研究和写作：Zettelkasten、Evergreen Notes 或 Progressive Formalization。
- 日常碎片很多：Inbox + Tags 或 Daily + MOC。
`;
}

function templateReadmeContent(template) {
  const folderList = template.folders.map((folder) => `- \`${folder}/\``).join("\n");

  return `# ${template.name}

## 中文说明

${template.zh}

适合：${template.bestForZh}

## English

${template.en}

Best for: ${template.bestForEn}

## Starter Folders

${folderList}

## First Use

1. Capture new notes into the inbox or first-stage folder.
2. Review the folder weekly.
3. Move reusable notes toward the more stable layer.
4. Delete folders that do not match your workflow.

## 第一次使用

1. 新内容先进入入口或第一阶段文件夹。
2. 每周固定清理一次。
3. 把可复用内容推向更稳定的层级。
4. 删除与你工作流不匹配的文件夹。
`;
}
